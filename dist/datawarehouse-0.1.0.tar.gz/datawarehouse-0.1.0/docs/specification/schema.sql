-- 外部キー制約を有効化
PRAGMA foreign_keys = ON;

-- task_table
CREATE TABLE IF NOT EXISTS task_table (
    task_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    task_set INTEGER,
    task_name TEXT,
    task_describe TEXT
);

-- subject_table
CREATE TABLE IF NOT EXISTS subject_table (
    subject_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_name TEXT
);

-- video_table
CREATE TABLE IF NOT EXISTS video_table (
    video_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    video_dir TEXT,
    subject_ID INTEGER,
    video_date TEXT,
    video_length INTEGER,
    FOREIGN KEY (subject_ID) REFERENCES subject_table(subject_ID) ON DELETE RESTRICT
);

-- tag_table
CREATE TABLE IF NOT EXISTS tag_table (
    tag_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    video_ID INTEGER,
    task_ID INTEGER,
    start INTEGER,
    end INTEGER,
    FOREIGN KEY (video_ID) REFERENCES video_table(video_ID) ON DELETE RESTRICT,
    FOREIGN KEY (task_ID) REFERENCES task_table(task_ID) ON DELETE RESTRICT
);

-- core_lib_table
CREATE TABLE IF NOT EXISTS core_lib_table (
    core_lib_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    core_lib_version TEXT,
    core_lib_update_information TEXT,
    core_lib_base_version_ID INTEGER,
    core_lib_commit_hash TEXT UNIQUE,
    FOREIGN KEY (core_lib_base_version_ID) REFERENCES core_lib_table(core_lib_ID) ON DELETE SET NULL
);

-- core_lib_output_table
CREATE TABLE IF NOT EXISTS core_lib_output_table (
    core_lib_output_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    core_lib_ID INTEGER,
    video_ID INTEGER,
    core_lib_output_dir TEXT,
    FOREIGN KEY (core_lib_ID) REFERENCES core_lib_table(core_lib_ID) ON DELETE RESTRICT,
    FOREIGN KEY (video_ID) REFERENCES video_table(video_ID) ON DELETE RESTRICT
);

-- algorithm_table
CREATE TABLE IF NOT EXISTS algorithm_table (
    algorithm_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    algorithm_version TEXT,
    algorithm_update_information TEXT,
    algorithm_base_version_ID INTEGER,
    algorithm_commit_hash TEXT UNIQUE,
    FOREIGN KEY (algorithm_base_version_ID) REFERENCES algorithm_table(algorithm_ID) ON DELETE SET NULL
);

-- algorithm_output_table
CREATE TABLE IF NOT EXISTS algorithm_output_table (
    algorithm_output_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    algorithm_ID INTEGER,
    core_lib_output_ID INTEGER,
    algorithm_output_dir TEXT,
    FOREIGN KEY (algorithm_ID) REFERENCES algorithm_table(algorithm_ID) ON DELETE RESTRICT,
    FOREIGN KEY (core_lib_output_ID) REFERENCES core_lib_output_table(core_lib_output_ID) ON DELETE RESTRICT
);

-- evaluation_result_table
CREATE TABLE IF NOT EXISTS evaluation_result_table (
    evaluation_result_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    version TEXT,
    algorithm_ID INTEGER,
    true_positive REAL,
    false_positive REAL,
    evaluation_result_dir TEXT,
    evaluation_timestamp TEXT,
    FOREIGN KEY (algorithm_ID) REFERENCES algorithm_table(algorithm_ID) ON DELETE RESTRICT
);

-- evaluation_data_table
CREATE TABLE IF NOT EXISTS evaluation_data_table (
    evaluation_data_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    evaluation_result_ID INTEGER,
    algorithm_output_ID INTEGER,
    correct_task_num INTEGER,
    total_task_num INTEGER,
    evaluation_data_path TEXT,
    FOREIGN KEY (evaluation_result_ID) REFERENCES evaluation_result_table(evaluation_result_ID) ON DELETE RESTRICT,
    FOREIGN KEY (algorithm_output_ID) REFERENCES algorithm_output_table(algorithm_output_ID) ON DELETE RESTRICT,
    CHECK (correct_task_num <= total_task_num)
);

-- 推奨インデックス
CREATE INDEX IF NOT EXISTS idx_core_lib_version ON core_lib_table(core_lib_version);
CREATE INDEX IF NOT EXISTS idx_algorithm_version ON algorithm_table(algorithm_version);



-- analysis_result_table（課題分析結果テーブル）
CREATE TABLE IF NOT EXISTS analysis_result_table (
    analysis_result_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    analysis_result_dir TEXT,
    analysis_timestamp TEXT,
    evaluation_result_ID INTEGER,
    FOREIGN KEY (evaluation_result_ID) REFERENCES evaluation_result_table(evaluation_result_ID) ON DELETE RESTRICT
);

-- problem_table（課題テーブル）
CREATE TABLE IF NOT EXISTS problem_table (
    problem_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    problem_name TEXT,
    problem_description TEXT,
    problem_status TEXT,
    analysis_result_ID INTEGER,
    FOREIGN KEY (analysis_result_ID) REFERENCES analysis_result_table(analysis_result_ID) ON DELETE RESTRICT
);

-- analysis_data_table（課題分析データテーブル）
CREATE TABLE IF NOT EXISTS analysis_data_table (
    analysis_data_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    evaluation_data_ID INTEGER,
    analysis_result_ID INTEGER,
    problem_ID INTEGER,
    analysis_data_isproblem INTEGER CHECK (analysis_data_isproblem IN (0,1)),
    analysis_data_dir TEXT,
    analysis_data_description TEXT,
    FOREIGN KEY (evaluation_data_ID) REFERENCES evaluation_data_table(evaluation_data_ID) ON DELETE RESTRICT,
    FOREIGN KEY (analysis_result_ID) REFERENCES analysis_result_table(analysis_result_ID) ON DELETE RESTRICT,
    FOREIGN KEY (problem_ID) REFERENCES problem_table(problem_ID) ON DELETE RESTRICT
);
